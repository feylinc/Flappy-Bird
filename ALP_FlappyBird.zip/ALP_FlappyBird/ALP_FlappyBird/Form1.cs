using static System.Formats.Asn1.AsnWriter;

namespace ALP_FlappyBird
{
    public partial class Form1 : Form
    {
        int pipeSpeed = 12;
        int gravity = 5;
        int score = 0;

        Random rnd = new Random();

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void bird_Click(object sender, EventArgs e)
        {

        }

        private void ground_Click(object sender, EventArgs e)
        {

        }

        private void scoreText_Click(object sender, EventArgs e)
        {

        }

        private void pipeDown_Click(object sender, EventArgs e)
        {

        }

        private void pipeUp_Click(object sender, EventArgs e)
        {

        }

        private void gameTimer(object sender, EventArgs e)
        {
            bird.Top += gravity; //tiap tekan space, burungnya naik pelan-pelan
            pipeUp.Left -= pipeSpeed; //pipa bawah geser ke kiri terus
            pipeDown.Left -= pipeSpeed; //pipa atas geser ke kiri terus
            scoreText.Text = "Score: " + score; //nampilin score

            if (pipeDown.Left < -180) //jarak sebanyak itu baru muncul pipa atas lagi
            {
                pipeDown.Left = 800;
                pipeDown.Top += rnd.Next(0, 40); //random tinggi pipa atas
            }

            if (pipeUp.Left < -120) //jarak sebanyak itu baru muncul pipa bawah lagi
            {
                pipeUp.Left = 950;
                pipeUp.Top += rnd.Next(-40, 0); //random tinggi pipa bawah
                score++; //nambah score tiap melewati 1 pipa bawah
            }

            if (bird.Bounds.IntersectsWith(pipeUp.Bounds) || bird.Bounds.IntersectsWith(pipeDown.Bounds) || bird.Bounds.IntersectsWith(ground.Bounds))
            {
                endGame(); //kalo burung bersentuhan sama pipa atau ground, game over
            }
        }

        private void keyIsDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Space)
            {
                gravity = -5; //tiap tekan space, burungnya naik sebanyak itu
            }
        }

        private void keyIsUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Space)
            {
                gravity = 5; //burungnya turun sebanyak itu
            }
        }

        private void endGame()
        {
            timer.Stop();
            scoreText.Text += "                                       GAME OVER"; //nampilin score + tulisan game over
        }
    }
}