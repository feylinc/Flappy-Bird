using static System.Formats.Asn1.AsnWriter;

namespace ALP_FlappyBird
{
    public partial class Form1 : Form
    {
        int pipeSpeed = 8;
        int gravity = 5;
        int score = 0;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void bird_Click(object sender, EventArgs e)
        {

        }

        private void ground_Click(object sender, EventArgs e)
        {

        }

        private void scoreText_Click(object sender, EventArgs e)
        {

        }

        private void pipeDown_Click(object sender, EventArgs e)
        {

        }

        private void pipeUp_Click(object sender, EventArgs e)
        {

        }

        private void gameTimer(object sender, EventArgs e)
        {
            bird.Top += gravity; //tiap tekan space, burungnya naik pelan-pelan
            pipeUp.Left -= pipeSpeed; //pipa bawah geser ke kiri terus
            pipeDown.Left -= pipeSpeed; //pipa atas geser ke kiri terus
            scoreText.Text = "Score: " + score; //nampilin score

            Random rnd = new Random();

            int randomPipe = rnd.Next(- 40, 40);
           

            if (pipeUp.Location.Y > 360)
            {
                randomPipe = rnd.Next(0, 40);
            }
            else if (pipeUp.Location.Y < 120)
            {
                randomPipe = rnd.Next(-40, 0);
            }

            if (pipeDown.Location.Y > 360)
            {
                randomPipe = rnd.Next(0, 40);
            }
            else if (pipeDown.Location.Y < 120)
            {
                randomPipe = rnd.Next(-40, 0);
            }

            if (pipeDown.Left < -180) //jarak sebanyak itu baru muncul pipa atas lagi 
            {
                pipeDown.Top += randomPipe;
                pipeDown.Left = 950;
                score++; //nambah score tiap lewatin 1 pipa atas
            }

            if (pipeUp.Left < -150) //jarak sebanyak itu baru muncul pipa bawah lagi
            {
                pipeUp.Top += randomPipe;
                pipeUp.Left = 800;
                score++; //nambah score tiap lewatin 1 pipa bawah
            }

            if (bird.Bounds.IntersectsWith(pipeUp.Bounds) || bird.Bounds.IntersectsWith(pipeDown.Bounds) || bird.Bounds.IntersectsWith(ground.Bounds) || bird.Top < -25)
            {
                endGame();
            }

            if (score > 5)
            {
                pipeSpeed = 15;
            }
        }

        private void keyIsDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Space)
            {
                gravity = -5; //tiap pencet space, burungnya naik sebanyak itu
            }

        }

        private void keyIsUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Space)
            {
                gravity = 5; //burungnya turun sebanyak itu
            }
        }

        private void endGame()
        {
            timer.Stop();
            scoreText.Text = "GAME OVER";
        }
    }
}