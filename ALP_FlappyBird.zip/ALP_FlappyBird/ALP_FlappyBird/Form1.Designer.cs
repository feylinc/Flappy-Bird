﻿namespace ALP_FlappyBird
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            pipeDown = new PictureBox();
            pipeUp = new PictureBox();
            bird = new PictureBox();
            ground = new PictureBox();
            scoreText = new Label();
            timer = new System.Windows.Forms.Timer(components);
            ((System.ComponentModel.ISupportInitialize)pipeDown).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pipeUp).BeginInit();
            ((System.ComponentModel.ISupportInitialize)bird).BeginInit();
            ((System.ComponentModel.ISupportInitialize)ground).BeginInit();
            SuspendLayout();
            // 
            // pipeDown
            // 
            pipeDown.Image = Properties.Resources.pipedown;
            pipeDown.Location = new Point(543, -139);
            pipeDown.Name = "pipeDown";
            pipeDown.Size = new Size(146, 397);
            pipeDown.SizeMode = PictureBoxSizeMode.StretchImage;
            pipeDown.TabIndex = 0;
            pipeDown.TabStop = false;
            pipeDown.Click += pipeDown_Click;
            // 
            // pipeUp
            // 
            pipeUp.Image = Properties.Resources.pipe;
            pipeUp.Location = new Point(815, 445);
            pipeUp.Name = "pipeUp";
            pipeUp.Size = new Size(146, 499);
            pipeUp.SizeMode = PictureBoxSizeMode.StretchImage;
            pipeUp.TabIndex = 1;
            pipeUp.TabStop = false;
            pipeUp.Click += pipeUp_Click;
            // 
            // bird
            // 
            bird.Image = Properties.Resources.bird;
            bird.Location = new Point(98, 291);
            bird.Name = "bird";
            bird.Size = new Size(90, 76);
            bird.SizeMode = PictureBoxSizeMode.StretchImage;
            bird.TabIndex = 2;
            bird.TabStop = false;
            bird.Click += bird_Click;
            // 
            // ground
            // 
            ground.Image = Properties.Resources.ground;
            ground.Location = new Point(-3, 678);
            ground.Name = "ground";
            ground.Size = new Size(1087, 97);
            ground.SizeMode = PictureBoxSizeMode.StretchImage;
            ground.TabIndex = 3;
            ground.TabStop = false;
            ground.Click += ground_Click;
            // 
            // scoreText
            // 
            scoreText.AutoSize = true;
            scoreText.BackColor = Color.Transparent;
            scoreText.Font = new Font("Arial Rounded MT Bold", 19.875F, FontStyle.Regular, GraphicsUnit.Point);
            scoreText.Location = new Point(6, 704);
            scoreText.Name = "scoreText";
            scoreText.Size = new Size(209, 61);
            scoreText.TabIndex = 4;
            scoreText.Text = "Score: ";
            scoreText.Click += scoreText_Click;
            // 
            // timer
            // 
            timer.Enabled = true;
            timer.Interval = 20;
            timer.Tick += gameTimer;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(13F, 32F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.LightSkyBlue;
            ClientSize = new Size(1080, 771);
            Controls.Add(scoreText);
            Controls.Add(ground);
            Controls.Add(bird);
            Controls.Add(pipeUp);
            Controls.Add(pipeDown);
            Name = "Form1";
            Text = " ";
            Load += Form1_Load;
            KeyDown += keyIsDown;
            KeyUp += keyIsUp;
            ((System.ComponentModel.ISupportInitialize)pipeDown).EndInit();
            ((System.ComponentModel.ISupportInitialize)pipeUp).EndInit();
            ((System.ComponentModel.ISupportInitialize)bird).EndInit();
            ((System.ComponentModel.ISupportInitialize)ground).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox pipeDown;
        private PictureBox pipeUp;
        private PictureBox bird;
        private PictureBox ground;
        private Label scoreText;
        private System.Windows.Forms.Timer timer;
        private Label label1;
    }
}